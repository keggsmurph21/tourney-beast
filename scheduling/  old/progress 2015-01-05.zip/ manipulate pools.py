import os
from datetime import datetime

# Function definitions

# Variable definitions
listList = []
listDivs = []
listPools = []
listTeams = []
listDivInfo = []
changelog = []

# Open files and save contents
f = open("pools.txt","r")
while 1:
    line = f.readline().strip()
    listList.append(line)
    if listList[len(listList)-1] == "end_list":
        listList.remove("end_list")
        break
f.close()

for entry in listList:
    if entry == "end_pool":
        listPools.append(listTeams)
        listTeams = []
    elif entry == "end_div":
        listDivs.append(listPools)
        listPools = []
    elif entry == "end_list":
        pass
    else:
        listTeams.append(entry)

g = open("division names.txt","r")
listList = []
while 1:
    line = g.readline().strip()
    listDivInfo.append(line)
    if listDivInfo[len(listDivInfo)-1] == "end_list":
        listDivInfo.remove("end_list")
        break
g.close()

while 1:
    finish = input("Continue editing? (y/n)\n").upper()
    if finish == "N": break
    while 1:
        print("Please choose a division to edit:\n(Enter the number index, e.g. 1)\n")
        for divIndex in range(len(listDivInfo)):
            print(str(divIndex+1) + ".\t" + listDivInfo[divIndex])
        divToEdit = int(input("\n")) - 1
        listAlphabet = ["A","B","C","D","E","F","G","H","I"]    
        print("Please choose which two teams should be switched:\n(Enter the letter-number index, e.g. A1)\n")
        for poolIndex in range(len(listDivs[divToEdit])):
            print("Pool %s" % listAlphabet[poolIndex])
            for teamIndex in range(len(listDivs[divToEdit][poolIndex])):
                print("\t"+str(teamIndex+1)+".\t"+listDivs[divToEdit][poolIndex][teamIndex])
        changelog.append(str(datetime.today()))
        teamOneUserEntry = input("\nTeam One: ").upper()
        teamTwoUserEntry = input("Team Two: ").upper()
        teamOneVector = [divToEdit,listAlphabet.index(teamOneUserEntry[0]),int(teamOneUserEntry[1])-1]
        teamTwoVector = [divToEdit,listAlphabet.index(teamTwoUserEntry[0]),int(teamTwoUserEntry[1])-1]
        changelog.append(listDivs[teamOneVector[0]][teamOneVector[1]][teamOneVector[2]])
        changelog.append(str(teamOneVector))
        changelog.append(listDivs[teamTwoVector[0]][teamTwoVector[1]][teamTwoVector[2]])
        changelog.append(str(teamTwoVector))
        changelog.append("")
        proceed = input("Switch %s and %s? (y/n)\n" %(listDivs[teamOneVector[0]][teamOneVector[1]][teamOneVector[2]], listDivs[teamTwoVector[0]][teamTwoVector[1]][teamTwoVector[2]])).upper()
        if proceed == "N": break
        placeholder = listDivs[teamOneVector[0]][teamOneVector[1]][teamOneVector[2]]
        listDivs[teamOneVector[0]][teamOneVector[1]][teamOneVector[2]] = listDivs[teamTwoVector[0]][teamTwoVector[1]][teamTwoVector[2]]
        listDivs[teamTwoVector[0]][teamTwoVector[1]][teamTwoVector[2]] = placeholder
        print("Switched %s and %s?\n" %(listDivs[teamOneVector[0]][teamOneVector[1]][teamOneVector[2]], listDivs[teamTwoVector[0]][teamTwoVector[1]][teamTwoVector[2]]))
        for poolIndex in range(len(listDivs[divToEdit])):
            print("Pool %s" % listAlphabet[poolIndex])
            for teamIndex in range(len(listDivs[divToEdit][poolIndex])):
                print("\t"+str(teamIndex+1)+".\t"+listDivs[divToEdit][poolIndex][teamIndex])
        break

# Save to two separate output files
if os.path.isfile("pools.txt"):
    os.remove("pools.txt")

f = open("pools.txt","a")
for div in listDivs:
    for pool in div:
        for team in pool:
            f.write(team+"\n")
        f.write("end_pool\n")
    f.write("end_div\n")
f.write("end_list\n")
f.close()

g = open("changelog.txt","a")
g.write("instance\n")
for entry in changelog:
    g.write(entry + "\n")
g.write("\n")
g.close()
