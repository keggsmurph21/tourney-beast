from random import shuffle

def findPSlot(s,n):
    for c in matrix:
        for t in c[0]:
            if s == t[0]:
                t[0] = t[0] - s
                t[1].append([s,n])
                dSz.remove([s,n])
                return
    return

def findISlot(s,n):
    leftover = 1
    while 1:
        for c in matrix:
            for t in c[0]:
                difference = (t[0] - s)
                if (difference <= leftover and difference>=0):
                    t[0] = t[0] - s
                    t[1].append([s,n])
                    dSz.remove([s,n])
                    return
        leftover += 1
    print("No matches at all")
    return

def view():
    for c in range(len(tourn)):
        for s in range(len(tourn[c])):
            print("Complex:",listComp[c][0],"\tTimeslot:",slotNames[s],"\n")
            for f in range(len(tourn[c][s])):
                print("\tField:",f+1)
                if len(tourn[c][s][f]):
                    for g in range(len(tourn[c][s][f])):
                        print("Game:",g+1,"\t",tourn[c][s][f][g])
                else: print("Empty field")
            print("\n")
        print("\n")
    print("\n")
    return
                    

numberOfGames = 0
gamesPerDay = 0
listTeamsDiv = []
listDivInfo = []
allOpp = []
listFields = {}
tourn = []
slotNames = ["Early morning","Late morning","Early afternoon","Late afternoon"]
listPieces = []
pieceInfo = []
d = []
dSz = []
matrix = []
fields = []
fGames = []

with open("schedule_h.py") as f:
    code = compile(f.read(),f,'exec')
    exec(code,globals())

for divID in range(len(listTeamsDiv)):
    for poolID in range(len(listTeamsDiv[divID])):
        sz = len(listTeamsDiv[divID][poolID])
        if not(sz % 2):
            listPieces.append(int(sz/2))
            pieceInfo.append([divID,poolID,0])
        else:
            listPieces.append(sz)
            pieceInfo.append([divID,poolID,1])
            poolID += 1

for i in range(len(listPieces)):
    d.append([pieceInfo[i],listPieces[i]])

d.sort()

for entry in d:
    dSz.append([entry[1],entry[0]])

dSz.sort(reverse=True)

for c in listComp:
    cMat = []
    for i in range(int(gamesPerDay/numberOfGames)):
        cMat.append([c[1],[]])
    matrix.append([cMat,c[0]])

matrix.sort(reverse = True)

for div in dSz:
    findPSlot(div[0],div[1])
    
for div in dSz:
    findISlot(div[0],div[1])

for cid in range(len(listComp)):
    fieldsC = []
    for tid in range(int(gamesPerDay/numberOfGames)):
        fieldsT = []
        idPool = 0
        idSum = 0
        for fid in range(listComp[cid][1]):
            if fid == (matrix[cid][0][tid][1][idPool][0] + idSum):
                idSum += matrix[cid][0][tid][1][idPool][0]
                idPool += 1
            if idPool > (len(matrix[cid][0][tid][1])-1):
                fieldsT.append([])          # fallow field
            else:
                fieldsT.append(matrix[cid][0][tid][1][idPool][1])
        fieldsC.append(fieldsT)
    fields.append(fieldsC)

for did in range(len(allOpp)):
    fGamesD = []
    for pid in range(len(allOpp[did])):
        fGamesP = []
        for teamid in range(len(allOpp[did][pid])):
            for tid in range(len(allOpp[did][pid][teamid])):
                fGamesP.append([])
                fGamesP[tid].append(sorted([allOpp[did][pid][teamid][tid],listTeamsDiv[did][pid][teamid]]))
        fGamesD.append(fGamesP)
    fGames.append(fGamesD)

for did in range(len(fGames)):
    for pid in range(len(fGames[did])):
        if (len(listTeamsDiv[did][pid]) % 2) and (pid % 2):
            for tid in range(len(fGames[did][pid])):
                for matchup in fGames[did][pid][tid]:
                    fGames[did][pid-1][tid].append(matchup)

for div in fGames:
    for pool in div:
        pool[:] = (i for i in pool if i != [])
        for timeslot in pool:
            timeslot.sort()
            for matchup in timeslot:
                if timeslot.count(matchup) > 1:
                    timeslot.remove(matchup)

# shuffle(withinPool)

for compid in range(len(listComp)):
    tournC = []
#    print("Complex:",listComp[compid],"\n")
    for slotid in range(len(fields[compid])):
        tournS = []
        divField = 0
#        print("Timeslot:",slotNames[slotid],"\n")
        while divField <= (len(fields[compid][0]) - 1):
            for gameid in range(fields[compid][slotid].count(fields[compid][slotid][divField])):
                tournF = []
                divInfo = fields[compid][slotid][divField]
#                print("\tField:",gameid+divField)
                if len(divInfo):
                    adjPool = divInfo[1] - (len(listTeamsDiv[divInfo[0]][divInfo[1]])%2 and divInfo[1]%2)
                    for timeid in range(numberOfGames):
                        tournF.append(fGames[divInfo[0]][adjPool][timeid][gameid])
#                        print("Game:",timeid+1,"\t",fGames[divInfo[0]][adjPool][timeid][gameid])
                else:
                    pass
                tournS.append(tournF)
#                    print("empty field")
#                print("\n")
            divField += fields[compid][slotid].count(fields[compid][slotid][divField])
        tournC.append(tournS)
    tourn.append(tournC)
#        print("\n")
#    print("\n")
