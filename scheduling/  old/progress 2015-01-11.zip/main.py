numberOfGames = 3
listTeamsDiv = []
listDivInfo = []
allOpp = []

listDivs = []
listPools = []
listPoolSize = []
listTeams = []
listList = []
listDivNumTeams = []

with open("program files/generate.py") as f:
    code = compile(f.read(),f,'exec')
    exec(code, globals())

with open("program files/opponents.py") as f:
    code = compile(f.read(),f,'exec')
    exec(code, globals())
    
while 1:
    print("Valid operations:")
    print("1. Edit pools.")
    print("2. View specific team's opponents.")
    print("3. View all teams and opponents.")
    operation = input("")

    if operation == "1":
        with open("program files/manipulate.py") as f:
            code = compile(f.read(),f,'exec')
            exec(code,globals())
        with open("program files/opponents.py") as f:
            code = compile(f.read(),f,'exec')
            exec(code, globals())
        print("\n**All opponents determined.**\n")

    if operation == "2":
        divID = int(input("Division index = "))
        poolID = int(input("Pool index = "))
        teamID = int(input("Team index = "))
        print("Chosen team:",listTeamsDiv[divID][poolID][teamID])
        print(allOpp[divID][poolID][teamID])
