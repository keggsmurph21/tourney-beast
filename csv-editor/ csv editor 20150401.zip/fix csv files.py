import csv

idealHeader = ['game','date','time','field','bracket','round','team','score']
listFiles = ['ccla 2014.csv','ccla 2013.csv','ccla 2012.csv','mixedcols.csv','event-hub-scores.csv','sepyla.csv']
csvFile = []
altNames = {'game'      :   ['game','game #','game id'],
            'date'      :   ['date','day'],
            'time'      :   ['time','start','start time'],
            'field'     :   ['field','location','place','facility'],
            'bracket'   :   ['bracket','division','group','pool'],
            'round'     :   ['round'],
            'team'      :   ['team'],
            'score'     :   ['score','final','final score'] }


def moveCol(newCol,oldCol):
    for row in csvFile:
        row.insert(newCol,row.pop(oldCol))

def delCol(col):
    for row in csvFile:
        row.pop(col)

def insCol(header):
    for r in range(len(csvFile)):
        if r:
            csvFile[r].append("")
        else:
            csvFile[r].append(header)

def clearCol(col):
    for row in csvFile:
        if row != csvHeader:
            row[col] = ""

def getHeader():
    headerRaw = csvFile[0]
    header = [i.lower() for i in headerRaw]
    
    return header

def fixHomeAway():
    csvHeader = getHeader()
    
    if csvHeader.count("home"):
        h = csvHeader.index("home")
    else:
        h = csvHeader.index("team")
        
    if csvHeader.count("away"):
        a = csvHeader.index("away")
    elif csvHeader.count("opponent"):
        a = csvHeader.index("opponent")
    else:
        a = csvHeader.index("visitor")

    csvFileEdited = []
    
    for r in range(len(csvFile)):
        newRow = csvFile[r]
        newRow[h] = newRow[a]
        
        del newRow[a]
        del csvFile[r][a]
        
        csvFileEdited.append(r)
        csvFileEdited.append(newRow)

    del csvFileEdited[0]
    del csvFileEdited[2]

    csvFileEdited[0][h] = "team"
    
    return csvFileEdited
            
def fixNoBracket():
    csvHeader = getHeader()
    insCol("bracket")
    
    tid = csvFile[0].index("team")
    bid = csvFile[0].index("bracket")
    
    for i in range(len(csvFile)):
        if i:
            team = csvFile[i][tid]
            splitTeam = team.split(" ")
            splitTeam.reverse()
            bracket = splitTeam[0]
            csvFile[i][bid] = bracket
            
def check(csvFile):
    csvHeader = getHeader()

    print("Correct header:\t",csvHeader==idealHeader)
    rowCount = 0

    while csvHeader.count('')/len(csvHeader)>.25:
        csvFile.pop(0)
        csvHeader = getHeader()
        rowCount += 1

    for item in csvHeader: item = item.lower()
    print("Deleted %i rows from top of sheet." % rowCount)

    colCount = 0

    while csvHeader.count(''):
        delCol(csvHeader.index(''))
        colCount += 1
        csvHeader = getHeader()

    print("Deleted %i empty columns from sheet." % colCount)

    if csvHeader.count("home") + csvHeader.count("away") + csvHeader.count("opponent"):
        print("Different home/away columns")
        fixHomeAway()

    csvHeader = getHeader()

    for header in idealHeader:
        hCount = 0
        for altHeader in altNames[header]:
            hCount += csvHeader.count(altHeader)
            if csvHeader.count(altHeader):
                csvFile[0][csvHeader.index(altHeader)] = header
                break

    csvHeader = getHeader()

    for header in idealHeader:
        if not(csvHeader.count(header)):
            if header == "bracket":
                fixNoBracket()
            else:
                print("No <%s> entered yet." % header.upper())
                insCol(header.upper())

    csvHeader = getHeader()

    print(csvHeader)
    for header in reversed(csvHeader):
        if not(idealHeader.count(header)):
            delCol(csvHeader.index(header))

    csvHeader = getHeader()

    if csvHeader != idealHeader:
        b = 0
        while b < len(csvHeader):
            for colID in range(len(csvHeader)):
                if idealHeader.count(csvHeader[colID]) and idealHeader.index(csvHeader[colID]) != colID:
                    moveCol(idealHeader.index(csvHeader[colID]),colID)
                    print("Moved column",csvHeader[colID])
                    csvHeader = getHeader()
                    b = 0
                b += 1

    return csvFile

for file in listFiles:
    csvFile = []
    headerID = 0

    print("File:\t",file,"\n")
    
    with open(file, newline='') as f:
        reader = csv.reader(f)
        for row in reader:
            csvFile.append(row)

    csvFile = check(csvFile)

    with open("edited_" + file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(csvFile)

    print("\n\n")
